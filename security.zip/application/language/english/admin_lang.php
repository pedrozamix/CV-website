<?php
/// dashbord and login
$lang['sign']      	 = "Sign";
$lang['sign_in']      	 = "Sign In";
$lang['out']      	 = "Out";
$lang['profile']      	 = "Profile";
$lang['remember_me']      	 = "Remember me";
$lang['forgot_password']      	 = "Forgot Password";
$lang['i_forgot_my_password']      	 = "I Forgot My Password";

$lang['register_new_admin']      	 = "Register New Student";

$lang['dashboard']      	 = "Dasbhoard";

$lang['hello']      	 = "Hello";
$lang['online']      	 = "Online";
$lang['username']      	 	= "Username";
$lang['password']      	 	= "Password";
$lang['add']      	 = "Add";
$lang['application']      		 	= "Application";


///// register

$lang['family_name']			= "Family Name";
$lang['first_name']			= "First Name";
$lang['dob']			= "Birth Of Date";
$lang['gender']			= "Gender";
$lang['Nationality']			= "Nationality";
$lang['Country']			= "Country of residence";
$lang['male']			= "Male";
$lang['Female']			= "Female";
$lang['male']      	 	= "Male";
$lang['female']      	 	= "Female";
$lang['other']      	 	= "Other";

$lang['yes']      	 	= "Yes";
$lang['no']      	 	= "No";
$lang['Undergraduate']			= "Undergraduate";
$lang['Postgraduate']			= "Postgraduate";
$lang['Email']			= "Email";
$lang['Tele']			= "Telephone";
$lang['start date']			= "When do you plan to start University?";
$lang['Research']			= "Research/PHD";
$lang['course']			= "Subject or course of interest?";
$lang['qualfiaction']			= "Qualfiaction";
$lang['registration']			= "You have been sucssfully registerd .. Please log in to complete the submission of the application";
$lang['apply_application']			= "Apply Application";
$lang['confirm']      	 	= "Confirm";



/// application

$lang['Choice 1']			= "Choice 1";
$lang['Choice 2']			= "Choice 2";
$lang['Choice 3']			= "Choice 3";
$lang['Month & year of entry']			= "Date Of Entry";
$lang['Level of entry']			= "Level Of Entry";
$lang['Have']			= "Have you previously studied in the UK?";
$lang['Month & year']			= "Date Of Entry";
$lang['yes']			= "Yes";
$lang['no']			= "No";
$lang['Title']			= "Title";
$lang['Mr']			= "Mr";
$lang['Mrs']			= "Mrs";
$lang['Ms']			= "Ms";
$lang['other']			= "Other";
$lang['Permanent home address']			= "Permanent home address";
$lang['Postcode']			= "Postcode";
$lang['Home tel']			= "Home tel (inc. dialing codes)";
$lang['Mobile']			= "Mobile (inc. dialing codes)";
$lang['Agency']			= "Agency (if applicable)";
$lang['Address for correspondence']			= "Address for correspondence, if different from above (e.g. agent's address)";
$lang['I am a permanent resident']			= "I am a permanent resident";
$lang['Outside the EU']			= "Outside the EU";
$lang['In the EU']			= "In the EU";
$lang['In the UK']			= "In the UK";
$lang['Country of birth']			= "Country of birth";
$lang['Nationality']			= "Nationality";
$lang['Country of']			= "Country of permanent residence";
$lang['Who is expected']			= "Who is expected to pay your fees? (ie self, employer, sponsor etc)";
$lang['from month']			= "From Month/Year";
$lang['month/year']			= "Month/Year";
$lang['to month']			= "To Month/Year";
$lang['month_to']			= "Month/Year";
$lang['organisation']			= "Name of organisation";
$lang['Position']			= "Position/job title";
$lang['duties']			= "Type of work/duties";
$lang['FT']			= "FT / PT";
$lang['PT']			= "PT";
$lang['TOEFL']			= "Type of Test eg IELTS, TOEFL";
$lang['Test']			= "Date of Test";
$lang['Criminal']			= "Do you have a relevant Criminal Conviction?";
$lang['referee']			= "Name of referee:";
$lang['Position']			= "Position";
$lang['Address']			= "Address";
$lang['Tel']			= "Tel (inc dialing codes)";
$lang['Fax']			= "Fax (inc dialing codes)";
$lang['email']			= "Email";
$lang['requirements']			= "If you have any special requirements, please give details of any support you may require";
$lang['requir']			= " require";
$lang['Information']			= "Marketing Information";
$lang['about our University']			= "Please tell us how you heard about our University";






