<?php 

/*********************add Remove Slashes  ************************



if(get_magic_quotes_gpc()){



$_GET = array_map('removeSlashes',$_GET);

$_POST= array_map('removeSlashes',$_POST);}

$_GET = array_map('addSaveSlashes',$_GET);

$_POST= array_map('addSaveSlashes',$_POST);

function removeSlashes($value){

	if(is_array($value)){$value = array_map('removeSlashe;;s',$value);}

	else $value=stripslashes($value);

	return $value;

}



function addSaveSlashes($value){

	if(is_array($value)){$value = array_map('addSaveSlashes',$value);}

	else{$value=mysql_real_escape_string($value);}

	return $value;

}



/********************Keywords************************/







function duration($start,$end=null) {

 $end = is_null($end) ? time() : $end;



 $seconds = $end - $start;

 

 $days = floor($seconds/60/60/24);

 $hours = $seconds/60/60%24;

 $mins = $seconds/60%60;

 $secs = $seconds%60;

 

 $duration='';

 if($days>0) $duration .= "$days days ";

 if($hours>0) $duration .= "$hours hours ";

 if($mins>0) $duration .= "$mins minutes ";

 if($secs>0) $duration .= "$secs seconds ";

 

 $duration = trim($duration);

 if($duration==null) $duration = '0 seconds';

 

 return $duration;}



function correct_encoding($text) {

	$ary[] = "ASCII";

$ary[] = "JIS";

$ary[] = "EUC-JP";

   $current_encoding = mb_detect_encoding($text,'auto');

    $text = iconv($current_encoding, 'UTF-8', $text);

    return $text;

}







function csv_to_array($filename='', $delimiter=';')

{setlocale(LC_ALL, 'ar_AE.utf8');

	if(!file_exists($filename) || !is_readable($filename))

		return FALSE;

	

	$header = NULL;

	$data = array();

	

	

	

	if (($handle = fopen($filename, 'r')) !== FALSE)

	

	{//var_dump($handle); exit;//= correct_encoding($handle);exit;

	// $handle = file_get_contents($filename, "r");

		while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE)

		{//echo '<br />'. correct_encoding($row['1']);

			if(!$header){

				$header = $row;

				}

			else{

				

				

				$data[] = array_combine($header, $row);

				//print_r($row);continue;

				}

		}

		fclose($handle);

	}

	

	//print_r($data);exit;

	return $data;

}























//--------countchar------

function countchar($str)

    {

    $count = 0;



    for($i = 0; $i < strlen($str); $i++)

        {

        $value = ord($str[$i]);

        if($value > 127)

            {

            if($value >= 192 && $value <= 223)

                $i++;

            elseif($value >= 224 && $value <= 239)

                $i = $i + 2;

            elseif($value >= 240 && $value <= 247)

                $i = $i + 3;

            else

                die('Not a UTF-8 compatible string');

            }

      

        $count++;

        }

  

    return $count;

    }





//-------createKeywords--------



function createKeywords($str){





$keyWord =preg_split("/[\s]+/",$str, 10);

$arrsize=count($keyWord);

$newStr="";

for($i=0;$i<=$arrsize;$i++){

//echo $keyWord[$i]."\t";

//echo countchar($keyWord[$i])."<br />";

if(countchar($keyWord[$i])>2){

//echo "strlin > 2";	

	

	switch ( $keyWord[$i] )

		{

		  case 'الى': 

			$newStr=$newStr;

			break;

		  case 'على': 

			$newStr=$newStr;

			break;

		  case 'إلى': 

			$newStr=$newStr;

			break;		  

		  default: // Works

		  if($newStr==""){$newStr=$newStr.$keyWord[$i];}

		  else{$newStr=$newStr."-".$keyWord[$i];}

		}//switch

	

			

}//if countchar	

	

}



return $newStr;



}

//-------clean_title--------

function clean_title($text)

{

//$text=strtolower($text);

$code_entities_match = array(' ','--','&quot;','!','@','#','$','%','^','&','*','(',')','_','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','.','/','*','+','~','`','=');

$code_entities_replace = array(' ',' ','','','','','','','','','','','','','','','','','','','','','','','','');

$text = str_replace($code_entities_match, $code_entities_replace, $text);

return $text;

}





/***********************chick url*****************************/





function curPageURL() {

 $pageURL = 'http';

 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}

 $pageURL .= "://";

 if ($_SERVER["SERVER_PORT"] != "80") {

  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];

 } else {

  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];

 }

 return $pageURL;

}







/***********************FaresMail*****************************/

function FaresMail($from,$fromName,$to,$subject,$message){

// To send HTML mail, the Content-type header must be set

$headers  = 'MIME-Version: 1.0' . "\r\n";

$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

// Additional headers

$headers .= 'To:'. "The site Manager <$to> " ."\r\n";

$headers .= 'From:'. " $fromName <$from> " . "\r\n";

// Mail it

return  mail($to, $subject, $message, $headers);



}



/***********************phpMailer*****************************/



function phpMailer($from,$fromName,$to,$subject,$message){

require_once("phpmailer/class.phpmailer.php"); // نضمن كود الكلاس الاساسي

include("phpmailer/class.smtp.php"); // نضمن كود الكلاس الخاص بسيرفر SMTP







$sname="=?UTF-8?B?".base64_encode($fromName)."?=\n"; // اسم المرسل

$smail=$from; // بريد المرسل

$rname="=?UTF-8?B?".base64_encode("WebExam Team")."?=\n"; // اسم المستقبل

$rmail=$to; // بريد المستقبل

$sub="=?UTF-8?B?".base64_encode($subject)."?=\n"; // موضوع الرسالة

// لم نقم بتشفير قيم البريد لكل من المرسل والمستقبل لانه بالاحرف اللاتينية

$body=$message; // نص الرسالة

/***************************/



$mail = new PHPMailer(); // defaults to using php "mail()"



/*************Smtp****************/

$mail->IsSMTP(); // نختار الارسال عن طريق SMTP

$mail->Host = '213.244.82.152'; // اسم سيرفر SMTP - ممكن ان يكون mail.yourdomain.com / smtp.yourdomain.com

$mail->SMTPAuth = true;

$mail->Username = "surgeryconf@moh.gov.ps"; // البريد الخاص بموقعك يجب ان ينتهي باسم موقعك

$mail->Password = "123456"; // كلمة مرور هذا البريد

/*********************************/

$mail->AddReplyTo($smail,$sname); // نختار وجهة ارسال الرد في حال ارسل واسم مستقبل الرد

$mail->SetFrom($smail,$sname);

$mail->AddReplyTo($smail,$sname);

$mail->AddAddress($rmail, $rname); // بريد المستقبل واسمه

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->Subject = $sub; // موضوع الرسالة

$mail->MsgHTML($body); // نص الرسالة - يمكن ان يكون كود html

//$mail->IsHTML(true); // send as HTML

$is_send=$mail->Send();

if(!$is_send) {

	$data['send']=$is_send;

	$data['msg']= "error occurred Try again </br>

					May be You enter a fake mail";

	 

}else{

	$data['send']=$is_send;

	$data['msg']= "Your message has been sent and will respond to you as soon as possible";

}

	return($data);

}

//----------------getRightBath---------------------------





function getRightBath($Boody)

{

$Wrong = array('src="../');

$Right= array('src="');

$Boody = str_replace($Wrong, $Right, $Boody);

	return $Boody;

}





//---------------------------------------------





function word_cut($text)

{

	

	

	$stop=0;

	$i=strlen($text);

	//echo $i.' ';

	while($i)

	{

		if($text[$i-1]==' ')

			break;

		else

			$text[$i-1]=' ';

		$i=$i-1;	

	}

	//echo $text;

	return $text;

}







function word_cut2($text , $no=100)

{   



$text= strip_tags($text);



if(strlen($text)<$no ){return $text; }else{

	

	$text=substr($text,0,$no);

	$stop=0;

	$i=strlen($text);

	//echo $i.' ';

	//echo"$text  N";exit;

	while($i)

	{

		if($text[$i-1]==' ')

			break;

		else

			$text[$i-1]=' ';

		$i=$i-1;	

	}

	//echo $text;

	return $text;

	

	

}

	

}

function url_bad_char($text)
	{
	$healthy = array("(",")"," ","’","&","`","'","ď","é","ê","!","°",":",",");
	$yummy   = array("-","-","-","-","-","-","-","d","e","e","","O"," "," ");
	return str_replace($healthy, $yummy, $text);
	
	}


function url_bad_char_for_keyword($text)
	{
	$healthy = array("(",")"," ","’","&","`","'","ď","é","ê","!","°",":",",");
	$yummy   = array(",",",",",",",",",",",",",","d","e","e"," ","O"," " ,"");
	return str_replace($healthy, $yummy, $text);
	
	}



/*********************check Domain Availability*****************************/



function checkDomainAvailability($domain) {

	echo"fares";

    if(preg_match('/[;\&\|\>\<]/', $domain)) exit; //Could be a hack attempt

    

     exec("whois " . escapeshellarg($domain), $output); //:CAREFUL:

    echo $result = implode("\n", $output);

    

    return (strpos($result, 'No match for domain') !== false);

}

/*************************************************************************/

function object2array($data) {

    if (is_array($data) || is_object($data))
    {
        $result = array();
        foreach ($data as $key => $value)
        {
            $result[$key] = object2array($value);
        }
        return $result;
    }
    return $data;



}









/*

using of it



$domain = 'bin-co.com';

if(checkDomainAvailability($domain)) {

	print "Domain '$domain' available.";

} else {

	print "Domain '$domain' NOT available. Sorry!";

}



*/



/***************getfiles in folder********************************/







function pass_encrypt($pass){

	$CI = & get_instance();

	$key=$CI->config->item('encryption_key');

	

	return md5(sha1(md5($pass.$key)));	//		 md5($_POST['pass']);

	}

	

	

	