<?php include("img_laib.php");  
//$gd_info_arr=gd_info();
//print_r($gd_info_arr);

function collect_my_photo($name,$sourse_paht,$sourse_img,$prand_path,$prand_photo, $sex,$width,$height){


$w="585"; 
$h="313"; 
$full=$sourse_paht."full_".$sourse_img;
fady_img_careat($w, $h, $full);



//$target = "img/my_prod1.jpg";
//$newcopy = "img/my_prod2.jpg";
$wtrmrk_file = "upload/photo/footer/foot_".$sex.".jpg";
fady_img_footer($full, $wtrmrk_file, $full);




$resized_file = $sourse_paht.$sourse_img;
$wmax = 220;
$hmax = 230;
$fileExt="jpg";
$new_size=$sourse_paht."size_".$sourse_img;

fady_img_resize($resized_file, $new_size, $wmax, $hmax, $fileExt);




//$target = "img/new.jpg";
//$newcopy = "img/my_prod.jpg";
$bottle_photo = $new_size;


fady_img_bottle($full, $bottle_photo, $full);




//prand
//$target = "img/my_prod.jpg";
//$newcopy = "img/my_prod1.jpg";
//$wtrmrk_file = "prand/logo_554dee8f94014.png";
//$title="fady fares فادي ";

$wmax = 250;
$hmax = 250;
$fileExt="png";
$newcopy=$prand_path."resize_150x150_".$prand_photo;



if($prand_photo !=""){
//echo $prand_path.$prand_photo;exit;
fady_img_resize($prand_path.$prand_photo,$newcopy, $wmax, $hmax, $fileExt);



//echo $prand_path.$prand_photo."<br />".$newcopy;exit;
fady_img_watermark($full, $newcopy, $full,$name);
}






$resized_file = $sourse_paht."collected_$width"."x".$height.$sourse_img;
$wmax = $width;
$hmax = $height;
$fileExt="jpg";


fady_img_resize($full, $resized_file, $wmax, $hmax, $fileExt);



$width="273";
$height="147";
$resized_file = $sourse_paht."collected_$width"."x".$height.$sourse_img;
fady_img_resize($full, $resized_file, $width, $height, $fileExt);


$width="184";
$height="98";
$resized_file = $sourse_paht."collected_$width"."x".$height.$sourse_img;
fady_img_resize($full, $resized_file, $width, $height, $fileExt);



$width="170";
$height="83";
$resized_file = $sourse_paht."collected_$width"."x".$height.$sourse_img;
fady_img_resize($full, $resized_file, $width, $height, $fileExt);


$width="111";
$height="60";
$resized_file = $sourse_paht."collected_$width"."x".$height.$sourse_img;
fady_img_resize($full, $resized_file, $width, $height, $fileExt);


//$wtrmrk_file = "upload/photo/footer/header.jpg";
//fady_img_header($full, $wtrmrk_file, $full,$name);



//exit;
}


function collect_my_photo2($name,$sourse_paht,$sourse_img,$prand_path,$prand_photo, $sex,$width,$height){


$w="585"; 
$h="313"; 
$full=$sourse_paht."full_".$sourse_img;
fady_img_careat($w, $h, $full);



//$target = "img/my_prod1.jpg";
//$newcopy = "img/my_prod2.jpg";
$wtrmrk_file = "upload/photo/footer/foot_".$sex.".jpg";
fady_img_footer($full, $wtrmrk_file, $full);


$resized_file = $sourse_paht.$sourse_img;
$wmax = 220;
$hmax = 230;
$fileExt="jpg";
$new_size=$sourse_paht."size_".$sourse_img;

fady_img_resize($resized_file, $new_size, $wmax, $hmax, $fileExt);




//$target = "img/new.jpg";
//$newcopy = "img/my_prod.jpg";
$bottle_photo = $new_size;


fady_img_bottle($full, $bottle_photo, $full);




//prand
//$target = "img/my_prod.jpg";
//$newcopy = "img/my_prod1.jpg";
//$wtrmrk_file = "prand/logo_554dee8f94014.png";
//$title="fady fares فادي ";

$wmax = 250;
$hmax = 250;
$fileExt="png";
$newcopy=$prand_path."resize_150x150_".$prand_photo;



if($prand_photo !=""){
//echo $prand_path.$prand_photo;exit;
fady_img_resize($prand_path.$prand_photo,$newcopy, $wmax, $hmax, $fileExt);



//echo $prand_path.$prand_photo."<br />".$newcopy;exit;
fady_img_watermark($full, $newcopy, $full,$name);
}






$resized_file = $sourse_paht."collected_$width"."x".$height.$sourse_img;
$wmax = $width;
$hmax = $height;
$fileExt="jpg";


fady_img_resize($full, $resized_file, $wmax, $hmax, $fileExt);
//exit;
}


