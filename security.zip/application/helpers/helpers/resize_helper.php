<?php 

//$CI =& get_instance();

function resize_to($img_name,$width,$height){
$CI =& get_instance();

$config['image_library'] 	= 'gd2';
$config['source_image'] 	= './upload/photo/'.$img_name;
$config['new_image'] 		= './upload/photo/thumb/'.$width.'x'.$height.'_'.$img_name;
$config['create_thumb'] 	= false;
$config['maintain_ratio'] 	= TRUE;
$config['width'] = $width;
$config['height']= $height;
$CI->load->library('image_lib', $config);
$CI->image_lib->resize();	
//echo "fares";exit;				
if (!$CI->image_lib->resize())
{echo $CI->image_lib->display_errors();}
else{
	
	return($config['new_image']);
	//$CI->config->item('base_url').'upload/photo/thumb/'.$width.'x'.$height.'_'.$img_name;
	}




	
	
	
} 



function crop_to($img_name,$width,$height){
$CI =& get_instance();

$config['image_library'] 	= 'gd2';
$config['source_image'] 	= './upload/photo/'.$img_name;
$config['new_image'] 		= './upload/photo/thumb/'.$width.'x'.$height.'_'.$img_name;
$config['create_thumb'] 	= false;
$config['maintain_ratio'] 	= TRUE;
$config['width'] = $width;
$config['height']= $height;
$CI->load->library('image_lib', $config);
//$CI->image_lib->resize();	
//echo "fares";exit;				
if (!$CI->image_lib->crop())
{echo $CI->image_lib->display_errors();}
else{
	
	return($config['new_image']);
	//$CI->config->item('base_url').'upload/photo/thumb/'.$width.'x'.$height.'_'.$img_name;
	}




	
	
	
} 