<?php
// Function for resizing jpg, gif, or png image files

function fady_img_careat($w, $h, $newcopy) {// Create a 100*30 image
$im = imagecreate($w, $h);

// White background and blue text
$bg = imagecolorallocate($im, 255, 255, 255);
//$textcolor = imagecolorallocate($im, 0, 0, 255);

// Write the string at the top left
//imagestring($im, 5, 0, 0, 'Hello world!', $textcolor);
 imagejpeg($im, $newcopy, 100);
}




function fady_img_resize($target, $newcopy, $w, $h, $ext) {
	//echo $target;exit();
    list($w_orig, $h_orig) = getimagesize($target);
    $scale_ratio = $w_orig / $h_orig;
	//echo $scale_ratio;exit;
	
    if (($w / $h) > $scale_ratio) {
           $w = $h * $scale_ratio;
    } else {
           $h = $w / $scale_ratio;
    }
    $img = "";
    $ext = strtolower($ext);
    if ($ext == "gif"){ 
      $img = imagecreatefromgif($target);
	   $tci = imagecreatetruecolor($w, $h);
    } else if($ext =="png"){ 
      
	  	$tci = imagecreatetruecolor( $w, $h );   
		imagealphablending( $tci, false );
		imagesavealpha( $tci, true );	  
	  	$img = imagecreatefrompng($target);
	  
	  
	  
	  
	  
    } else { 
      $img = imagecreatefromjpeg($target);
	   $tci = imagecreatetruecolor($w, $h);
    }
    //$tci = imagecreatetruecolor($w, $h);
    // imagecopyresampled(dst_img, src_img, dst_x, dst_y, src_x, src_y, dst_w, dst_h, src_w, src_h)
    imagecopyresampled($tci, $img, 0, 0, 0, 0, $w, $h, $w_orig, $h_orig);
   
    if($ext =="png"){ 
	 	imagepng($tci, $newcopy, 9);
      
    } else {
		 imagejpeg($tci, $newcopy, 100);
		
		}
   
   
}

function fady_image_rotate($imag , $new_path){
	
	
$sourse=imagecreatefromjpeg($imag);
	
$imagrotated=imagerotate($sourse,45,-1);	
imagejpeg($imagrotated,$new_path,100);

}



function fady_img_bottle($target, $wtrmrk_file, $newcopy) { 
    $watermark = imagecreatefromjpeg($wtrmrk_file); 
    imagealphablending($watermark, false); 
    imagesavealpha($watermark, true); 
    $img = imagecreatefromjpeg($target);
    $img_w = imagesx($img); 
    $img_h = imagesy($img); 
    $wtrmrk_w = imagesx($watermark); 
    $wtrmrk_h = imagesy($watermark); 
	
	$dst_x = ($img_w - $wtrmrk_w)-60; // For centering the watermark on any image
	$dst_y = (262-$wtrmrk_h); // For centering the watermark on any image
    
	imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h); 
    imagejpeg($img, $newcopy, 100); 
    imagedestroy($img); 
    imagedestroy($watermark); 

} 



function fady_img_watermark($target, $wtrmrk_file, $newcopy ,$title="", $ext="png") { 

 if ($ext == "png"){ 
      
	   $watermark = imagecreatefrompng($wtrmrk_file); 
    } else { 

    $watermark = imagecreatefromjpeg($wtrmrk_file); 
	}



    imagealphablending($watermark, false); 
    imagesavealpha($watermark, true); 
    $img = imagecreatefromjpeg($target);
    $img_w = imagesx($img); 
    $img_h = imagesy($img); 
    $wtrmrk_w = imagesx($watermark); 
    $wtrmrk_h = imagesy($watermark); 
	
	
$dst_x = 60;
$dst_y = (265-$wtrmrk_h)/2;
imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h); 	
	
	

    imagejpeg($img, $newcopy, 100); 
    imagedestroy($img); 
    imagedestroy($watermark); 

} 

function fady_img_header($target, $wtrmrk_file, $newcopy,$title="") { 
    $watermark = imagecreatefromjpeg($wtrmrk_file); 
    imagealphablending($watermark, false); 
    imagesavealpha($watermark, true); 
    $img = imagecreatefromjpeg($target);
    $img_w = imagesx($img); 
    $img_h = imagesy($img); 
    $wtrmrk_w = imagesx($watermark); 
    $wtrmrk_h = imagesy($watermark); 
	
	//$dst_x = 40;
//    $dst_y = 20;
    $dst_x = 0; // For centering the watermark on any image
    $dst_y = 0; // For centering the watermark on any image
    imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h); 
	
	
	
	
	
	
	// Create some colors
$white = imagecolorallocate($img, 255, 255, 255);
$grey = imagecolorallocate($img, 128, 128, 128);
$black = imagecolorallocate($img, 0, 0, 0);
imagefilledrectangle($img, 0, 0, 399, 29, $white);

$font = 'font/bebasneue-webfont.ttf';
$type_space = imagettfbbox("25", 0, $font, $title);
$image_width = abs($type_space[4] - $type_space[0]);
$image_height = abs($type_space[5] - $type_space[1]);
	
$text_x=0;
$text_y=0;
$mytext= imagettftext($img,25, 0, $text_x, $text_y, $grey, $font, $title);
	
   
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    imagejpeg($img, $newcopy, 100); 
    imagedestroy($img); 
    imagedestroy($watermark); 
} 

function fady_img_footer($target, $wtrmrk_file, $newcopy) { 
    $watermark = imagecreatefromjpeg($wtrmrk_file); 
    imagealphablending($watermark, false); 
    imagesavealpha($watermark, true); 
    $img = imagecreatefromjpeg($target);
    $img_w = imagesx($img); 
    $img_h = imagesy($img); 
    $wtrmrk_w = imagesx($watermark); 
    $wtrmrk_h = imagesy($watermark); 
	
	//$dst_x = 40;
//    $dst_y = 20;
    $dst_x = 0; // For centering the watermark on any image
    $dst_y = ($img_h ) - ($wtrmrk_h ); // For centering the watermark on any image
    imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h); 
    imagejpeg($img, $newcopy, 100); 
    imagedestroy($img); 
    imagedestroy($watermark); 
} 

function fady_careat_new_img_name($target) { 
    
	$patharray=explode( '/', $target );
	$photo_name=$patharray[count($patharray)-1];
	$new_photo="collected".$photo_name;
	
} 
