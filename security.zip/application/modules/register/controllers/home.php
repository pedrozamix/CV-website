<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->auth->check_session();
		
	}
	

	
	function index()
	{	
	$this->load->view('header');	
	$this->load->view('home');
	$this->load->view('footer');	
	}
	
	
	public function aboutus()
	{
			$this->load->view('header');	
		    $this->load->view('aboutus');
			$this->load->view('footer'); 
				
	}
	
	public function contactus()
	{
			$this->load->view('header');	
		    $this->load->view('contactus'); 
			$this->load->view('footer');
				
	}
	
	public function university()
	{
			$this->load->view('header');	
		    $this->load->view('university'); 
			$this->load->view('footer');
				
	}
	
	public function study_courses()
	{
			$this->load->view('header');	
		    $this->load->view('study_courses'); 
			$this->load->view('footer');
				
	}
	
	public function accommodation()
	{
			$this->load->view('header');	
		    $this->load->view('accommodation');
			$this->load->view('footer'); 
				
	}
	
	public function location()
	{
			$this->load->view('header');	
		    $this->load->view('location');
			$this->load->view('footer');  
				
	}
	
	public function facilities()
	{
			$this->load->view('header');	
		    $this->load->view('facilities'); 
			$this->load->view('footer');
				
	}
	
	public function undergraduate()
	{
			$this->load->view('header');	
		    $this->load->view('undergraduate');
			$this->load->view('footer'); 
				
	}
	
	public function post_graduate()
	{
			$this->load->view('header');	
		    $this->load->view('post_graduate'); 
			$this->load->view('footer');
				
	}
	
	

	
	
	
}