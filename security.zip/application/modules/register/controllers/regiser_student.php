<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Regiser_student extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->auth->check_session();
		
	}
	
	function sendmail()
	{extract($_POST);	
	$from='info@badereu.com';
	$fromName="badereu.com";
	$to=$email;//"ahmed.qumsan@gmail.com;";//$email;
	$subject="Thanks You Mr." .$to. " For Registration";
	$message="Thank you for your registration in our WebSite \r\n Now you can login through the site and apply the application";

FaresMail($from,$fromName,$to,$subject,$message);


	}
	
	
	function index()
	{	
     // error_reporting(0);
		//if (isset($_POST['submit'])){
		if ($this->input->server('REQUEST_METHOD') === 'POST')
		
	

        {	
			$this->load->library('form_validation');
			$this->form_validation->set_rules('name', 'lang:family_name', 'required|xss_clean');
			$this->form_validation->set_rules('first_name', 'lang:first_name', 'required|xss_clean');
			$this->form_validation->set_rules('dob', 'lang:dob', 'required|xss_clean');
			$this->form_validation->set_rules('gender', 'lang:gender', 'required|xss_clean');
			$this->form_validation->set_rules('Nationality', 'lang:Nationality', 'required|xss_clean');
			$this->form_validation->set_rules('Country', 'lang:Country', 'required|xss_clean');
		    $this->form_validation->set_rules('email', 'lang:email', 'trim|required|valid_email|max_length[128]|is_unique[users.email]|xss_clean');
			$this->form_validation->set_rules('phone', 'lang:phone', 'required|xss_clean');
			$this->form_validation->set_rules('course', 'lang:course', 'required|xss_clean');
			$this->form_validation->set_rules('level_study', 'lang:level_study', 'required|xss_clean');
			$this->form_validation->set_rules('start_date', 'lang:start_date', 'required|xss_clean');
			$this->form_validation->set_rules('username', 'lang:username', 'trim|required|is_unique[users.username]|xss_clean');
			$this->form_validation->set_rules('password', 'lang:password', 'required|min_length[6]|xss_clean');
			$this->form_validation->set_rules('conf', 'lang:confirm_password', 'required|matches[password]|xss_clean');

		   
			if ($this->form_validation->run()==true)
            {
				
			    $name= $this->input->post('name');
				$first_name = $this->input->post('first_name');
                $dob = $this->input->post('dob');
				$gender = $this->input->post('gender');
				$Nationality = $this->input->post('Nationality');
				$Country = $this->input->post('Country');
				$email = $this->input->post('email');
				$phone = $this->input->post('phone');
				$course = $this->input->post('course');
				$level_study = $this->input->post('level_study');
				$start_date = $this->input->post('start_date');
				$username = $this->input->post('username');
				$password = sha1($this->input->post('password'));
				


				$query = "INSERT INTO users (family_name, first_name, dob, gender,Nationality,Country,email
				,phone,course,level_study ,start_date, username,   password) VALUES('".$this->db->escape_str($name)."' ,
				 '".$this->db->escape_str($first_name)."', ".$this->db->escape_str($dob).", '".$this->db->escape_str($gender)."'
				 ,'".$this->db->escape_str($Nationality)."','".$this->db->escape_str($Country)."','".$this->db->escape_str($email)."',
				 '".$this->db->escape_str($phone)."','".$this->db->escape_str($course)."','".$this->db->escape_str($level_study)."',
				 ".$this->db->escape_str($start_date).",'".$this->db->escape_str($username)."','".$this->db->escape_str($password)."')";
   				
				$this->db->query($query);
				
				echo '<script> alert("Registration Success");</script>';
				
				 //$this->session->set_flashdata('message', lang('registration'));
				
				//$this->session->set_flashdata('message', lang('registration'));
			//	$sql = "INSERT INTO table (title) VALUES('".$this->db->escape_str($title)."')";
			}
		}		

	$this->load->view('regiser_student');
	
		
	
	
	}
	
	

	
	
	
}