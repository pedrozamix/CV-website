<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
        <meta charset="UTF-8">
        <title>E-Registration Student System | Registration New Student</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        
        
         <link rel="stylesheet" href="<?php echo base_url('assets/css/datepicker.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css')?>">
        <style>
		.body01{
			color:#333333 !important;}
		</style>
        
        
         <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <link href="<?php echo base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="<?php echo base_url('assets/css/ionicons.min.css')?>" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
  
    <!-- Theme style -->
    <link href="<?php echo base_url('assets/css/jquery.datetimepicker.css')?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo base_url('assets/css/AdminLTE.css')?>" rel="stylesheet" type="text/css" />
    
    
    <!-- jQuery 2.0.2 -->
    <script src="<?php echo base_url('assets/js/jquery.js')?>"></script>
	
	  <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/js/jquery.datetimepicker.js')?>" type="text/javascript"></script>



        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="bg-black">



<div style="padding:20px;">
			<?php if(validation_errors()): ?>
                    <div class="alert alert-danger alert-dismissable col-md-11">
                        <i class="fa fa-ban"></i>
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                       <?php echo validation_errors(); ?>
                    </div>
                    <?php endif; ?>
                    <!--style top and red alert-->
     </div> 
     
    


 
		<div class="form-box" id="login-box">
       
        <?php echo form_open_multipart('register/regiser_student/'); ?>
           <?php 
		   	echo '
			    <div class="header">'.lang("register_new_admin").'</div>
           		
                <div class="body bg-gray">
                    <div class="form-group">
                        <input type="text" name="name" value="'.set_value('name').'" class="form-control" placeholder="'.lang("family_name").'"/>
                    </div>
                    <div class="form-group">
                        <input type="text" name="first_name" value="'.set_value('first_name').'" class="form-control" placeholder="'.lang("first_name").'"/>
                    </div>
                    <div class="form-group">
                        <input type="text"  name="dob" value="'.set_value('dob').'" id="example2" class="form-control" placeholder="'.lang("dob").'"/>
                    </div>
                   <div class="form-group">
									<select name="gender" class="form-control chzn">
										<option value="-1">-- '.lang("gender").' --</option>
										<option value="male"> '.lang("male").'  </option>
										<option value="female"> '.lang("female").' </option>
										
									</select>
					
					
					
					</div>
					<div class="form-group">
                        <input type="text" value="'.set_value('Nationality').'" name="Nationality" class="form-control" placeholder="'.lang("Nationality").'"/>
                    </div>
					
					<div class="form-group">
                        <input type="text" value="'.set_value('Country').'" name="Country" class="form-control" placeholder="'.lang("Country").'"/>
                    </div>
					
					<div class="form-group">
                        <input type="text" value="'.set_value('email').'" name="email" class="form-control" placeholder="'.lang("Email").'"/>
                    </div>
					
					<div class="form-group">
                        <input type="text" value="'.set_value('phone').'" name="phone" class="form-control" placeholder="'.lang("Tele").'"/>
                    </div>
					<div class="form-group">
                        <input type="text" value="'.set_value('course').'" name="course" class="form-control" placeholder="'.lang("course").'"/>
                    </div>
					<div class="form-group">
									<select name="level_study" class="form-control chzn">
										<option value="-1">--'.lang("qualfiaction").'--</option>
										<option value="Undergraduate"> '.lang("Undergraduate").'  </option>
										<option value="Undergraduate"> '.lang("Undergraduate").' </option>
										<option value="Research">'.lang("Research").' </option>
										
									</select>
					
					
					
					</div>
					 <input id="example1" value="'.set_value('start_date').'" type="text" name="start_date"  class="form-control datepicker" placeholder="'.lang("start date").'"/>
					 
					
                
				<div class="form-group">
                        <input type="text" value="'.set_value('username').'" name="username" class="form-control" placeholder="'.lang("username").'"/>
                    </div>
					<div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="'.lang("password").'"/>
                    </div>
					<div class="form-group">
                        <input type="password" name="conf" class="form-control" placeholder="'.lang("confirm").'"/>
                    </div>
				</div>
						
                <div class="footer" style="padding-left:245px">

                    <button type="submit" class="btn bg-olive btn-block" style="color:#fff !important;  border: 1px solid transparent;
    border-radius: 0;
    box-shadow: 0 -1px 0 0 rgba(0, 0, 0, 0.09) inset;
    float: right;
    font-weight: 500;
    margin-right: -20px;
    margin-top: -10px;
    width: 600px;">Register</button>

                    
                </div>
        
				';
		   ?>
        </div>
          <?php form_close()?>
         <br>
         <br>
         <br>
 <script src="<?php echo base_url('assets/js/jquery-1.9.1.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap-datepicker.js')?>"></script>
        <script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
                $('#example1').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
			
			 $('#example2').datepicker({
                    format: "yyyy-mm-dd"
                }); 
            });
        </script>

    </body>
	
</html>
