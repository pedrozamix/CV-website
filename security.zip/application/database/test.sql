-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 29, 2016 at 08:29 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `always_allowed` tinyint(1) NOT NULL DEFAULT '1',
  `alias` varchar(255) NOT NULL,
  `is_hidden` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=173 ;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`id`, `name`, `parent_id`, `always_allowed`, `alias`, `is_hidden`) VALUES
(1, 'login', 0, 0, 'Authentication', 0),
(2, 'login', 1, 1, 'Login', 0),
(3, 'logout', 1, 1, 'Logout', 0),
(4, 'cases', 0, 0, 'All Case', 0),
(5, 'add', 4, 0, 'Add', 0),
(6, 'edit', 4, 0, 'Edit', 0),
(7, 'view_case', 4, 0, 'View Case', 0),
(8, 'fees', 4, 0, 'Fees', 0),
(9, 'archived', 4, 0, 'Archived', 0),
(10, 'starred_cases', 4, 0, 'Starred Cases', 0),
(11, 'archived_cases', 4, 0, 'Archived Cases', 0),
(12, 'view_archived_case', 4, 0, 'View Archived Case', 0),
(13, 'restore', 4, 0, 'Restore', 0),
(14, 'reports', 0, 0, 'Reports', 0),
(15, 'message', 4, 0, 'Message', 0),
(16, 'to_do_list', 0, 0, 'To Do List', 0),
(17, 'add', 16, 0, 'Add', 0),
(18, 'edit', 16, 0, 'Edit', 0),
(19, 'view_to_do', 16, 0, 'View', 0),
(20, 'delete', 16, 0, 'Delete', 0),
(21, 'contacts', 0, 0, 'Contacts', 0),
(22, 'add', 21, 0, 'Add', 0),
(23, 'edit', 21, 0, 'Edit', 0),
(24, 'delete', 21, 0, 'Delete', 0),
(25, 'appointments', 0, 0, 'Appointments', 0),
(26, 'add', 25, 0, 'Add', 0),
(27, 'edit', 25, 0, 'Edit', 0),
(28, 'delete', 25, 0, 'Delete', 0),
(29, 'view_appointment', 25, 0, 'View', 0),
(30, 'custom_fields', 0, 0, 'Custom Fields', 0),
(31, 'delete', 30, 0, 'Delete', 0),
(32, 'clients', 0, 0, 'Clients', 0),
(33, 'add', 32, 0, 'Add', 0),
(34, 'edit', 32, 0, 'Edit', 0),
(35, 'delete', 32, 0, 'Delete', 0),
(36, 'view_client', 32, 0, 'View', 0),
(37, 'employees', 0, 0, 'Employees', 0),
(38, 'add', 37, 0, 'Add', 0),
(39, 'edit', 37, 0, 'Edit', 0),
(40, 'delete', 37, 0, 'Delete', 0),
(41, 'view', 37, 0, 'View', 0),
(42, 'user_role', 0, 0, 'User Role', 0),
(43, 'add', 42, 0, 'Add', 0),
(44, 'edit', 42, 0, 'Edit', 0),
(45, 'delete', 42, 0, 'Delete', 0),
(46, 'departments', 0, 0, 'Departments', 0),
(47, 'add', 46, 0, 'Add', 0),
(48, 'edit', 46, 0, 'Edit', 0),
(49, 'delete', 46, 0, 'Delete', 0),
(50, 'permissions', 0, 0, 'Permissions', 0),
(51, 'location', 0, 0, 'Location', 0),
(52, 'add', 51, 0, 'Add', 0),
(53, 'edit', 51, 0, 'Edit', 0),
(54, 'delete', 51, 0, 'Delete', 0),
(55, 'case_category', 0, 0, 'Case Category', 0),
(56, 'add', 55, 0, 'Add', 0),
(57, 'edit', 55, 0, 'Edit', 0),
(58, 'delete', 57, 0, 'Delete', 0),
(59, 'court_category', 0, 0, 'Court Category', 0),
(60, 'add', 59, 0, 'Add', 0),
(61, 'edit', 59, 0, 'Edit', 0),
(62, 'delete', 59, 0, 'Delete', 0),
(63, 'act', 0, 0, 'Act', 0),
(64, 'add', 63, 0, 'Add', 0),
(65, 'edit', 63, 0, 'Edit', 0),
(66, 'delete', 63, 0, 'Delete', 0),
(67, 'court', 0, 0, 'Court', 0),
(68, 'add', 67, 0, 'Add', 0),
(69, 'edit', 67, 0, 'Edit', 0),
(70, 'delete', 67, 0, 'Delete', 0),
(71, 'case_stage', 0, 0, 'Case Stages', 0),
(72, 'add', 71, 0, 'Add', 0),
(73, 'edit', 71, 0, 'Edit', 0),
(74, 'delete', 71, 0, 'Delte', 0),
(75, 'payment_mode', 0, 0, 'Payment Modes', 0),
(76, 'add', 75, 0, 'Add', 0),
(77, 'edit', 75, 0, 'Edit', 0),
(78, 'delete', 75, 0, 'Delete', 0),
(79, 'settings', 0, 0, 'Settings', 0),
(80, 'notification', 0, 0, 'Notification', 0),
(81, 'languages', 0, 0, 'Languages', 0),
(82, 'edit', 81, 0, 'Edit', 0),
(83, 'delete', 81, 0, 'Delete', 0),
(84, 'dates', 4, 0, 'Hearing Date', 0),
(85, 'get_court_categories', 4, 1, 'get_court_categories', 1),
(86, 'get_courts', 4, 1, 'get_courts', 1),
(87, 'get_case_by_client', 4, 1, '', 1),
(88, 'get_case_by_court', 4, 1, '', 1),
(89, 'get_case_by_location', 4, 1, '', 1),
(90, 'get_case_by_case_stage_id', 4, 1, '', 1),
(91, 'get_case_by_case_filing_date', 4, 1, '', 1),
(92, 'get_case_by_case_hearing_date', 4, 1, '', 1),
(93, 'get_case_by_client_starred', 4, 1, '', 1),
(94, 'get_case_by_court_starred', 4, 1, '', 1),
(95, 'get_case_by_location_starred', 4, 1, '', 1),
(96, 'get_case_by_case_stage_id_starred', 4, 1, '', 1),
(97, 'get_case_by_case_filing_date_starred', 4, 1, '', 1),
(98, 'get_case_by_case_hearing_date_starred', 4, 1, '', 1),
(99, 'get_archive_case_by_client', 4, 1, '', 1),
(100, 'get_archive_case_by_court', 4, 1, '', 1),
(101, 'get_archive_case_by_location', 4, 1, '', 1),
(102, 'get_archive_case_by_case_stage_id', 4, 1, '', 1),
(103, 'get_archive_case_by_case_filing_date', 4, 1, '', 1),
(104, 'get_archive_case_by_case_hearing_date', 4, 1, '', 1),
(105, 'view_all', 4, 0, 'Case Alert', 0),
(106, 'view_all', 25, 0, 'Appointment Alert', 0),
(107, 'view_all', 16, 0, 'To Do Alert', 0),
(108, 'invoice', 0, 0, 'Invoice', 0),
(109, 'mail', 108, 0, 'Mail', 0),
(110, 'pdf', 108, 0, 'Pdf', 0),
(111, 'send', 15, 0, 'Send Message', 0),
(112, 'tasks', 0, 0, 'Tasks', 0),
(113, 'add', 112, 0, 'Add', 0),
(114, 'edit', 112, 0, 'Edit', 0),
(115, 'view', 112, 0, 'View', 0),
(116, 'delete', 112, 0, 'Delete', 0),
(117, 'comments', 112, 0, 'Comments', 0),
(118, 'documents', 0, 0, 'Documents', 0),
(119, 'add', 118, 0, 'Add', 0),
(120, 'edit', 118, 0, 'Edit', 0),
(121, 'delete', 118, 0, 'Delete', 0),
(122, 'manage', 118, 0, 'Manage', 0),
(123, 'bank_details', 37, 0, 'Bank Details', 0),
(124, 'add_bank_details', 37, 0, 'Add Bank Details', 0),
(125, 'delete_bank_details', 37, 0, 'Delete Bank Details', 0),
(126, 'documents', 37, 0, 'Documents', 0),
(127, 'delete_document', 37, 0, 'Delete Documents', 0),
(128, 'download', 118, 1, 'Download', 1),
(129, 'attendance', 0, 0, 'Attendance', 0),
(130, 'leave_notification', 129, 0, 'Leave Notification', 0),
(131, 'update_leave', 129, 0, 'Pending /Approve Leave', 0),
(132, 'delete_leave', 129, 0, 'Delete Leave', 0),
(133, 'mark_in', 129, 0, 'Mark In', 0),
(134, 'mark_out', 129, 0, 'Mark Out', 0),
(135, 'my_attendance', 129, 0, 'My Attendance', 0),
(136, 'my_leaves', 129, 0, 'My Leaves', 0),
(137, 'apply_leave', 129, 0, 'Apply Leave', 0),
(138, 'delete_my_leave', 129, 0, 'Delete My Leave', 0),
(139, 'leave_types', 0, 0, 'Leave Types', 0),
(140, 'add', 139, 0, 'Add', 0),
(141, 'edit', 139, 0, 'Edit', 0),
(142, 'delete', 139, 0, 'Delete', 0),
(143, 'holidays', 0, 0, 'Holidays', 0),
(144, 'add', 143, 0, 'Add', 0),
(145, 'delete', 143, 0, 'Delete', 0),
(146, 'notice', 0, 0, 'Notice', 0),
(147, 'add', 146, 0, 'Add', 0),
(148, 'edit', 146, 0, 'Edit', 0),
(149, 'Delete', 146, 0, 'Delete', 0),
(150, 'view', 146, 0, 'View', 0),
(151, 'switch_language', 81, 1, 'Change Language', 1),
(152, 'my_tasks', 112, 0, 'My Tasks', 0),
(153, 'delete_document', 118, 0, 'My Delete DOcument', 0),
(154, 'get_degi', 37, 1, 'Get Employees Degination By Ajax', 1),
(155, 'view', 21, 0, 'Contact', 0),
(156, 'notes', 4, 0, 'Notes', 0),
(157, 'tax', 0, 0, 'Tax', 0),
(158, 'add', 157, 0, 'Add', 0),
(159, 'edit', 157, 0, 'Edit', 0),
(160, 'delete', 157, 0, 'Delete', 0),
(161, 'case_study', 0, 0, 'Case Study', 0),
(162, 'add', 161, 0, 'Add', 0),
(163, 'edit', 161, 0, 'Edit', 0),
(164, 'delete', 161, 0, 'Delete', 0),
(165, 'view', 161, 0, 'View', 0),
(166, 'delete_fees', 4, 0, 'Delete Fees', 0),
(167, 'view_receipt', 4, 0, 'View Receipt', 0),
(168, 'print_receipt', 4, 1, 'Print Receipt', 1),
(169, 'delete_receipt', 4, 0, 'Delete Receipt', 0),
(170, 'dates_detail', 4, 0, 'View Case Extended Date Details', 0),
(171, 'delete_history', 4, 0, 'Delete Case Extended Dates', 0),
(172, 'attachments', 161, 0, 'Attachments', 0);

-- --------------------------------------------------------

--
-- Table structure for table `experiences`
--

CREATE TABLE IF NOT EXISTS `experiences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_date_expr` date NOT NULL,
  `to_date_expr` date NOT NULL,
  `organisation_expr` varchar(500) CHARACTER SET utf8 NOT NULL,
  `Position_expr` varchar(500) CHARACTER SET utf8 NOT NULL,
  `duties_expr` varchar(500) CHARACTER SET utf8 NOT NULL,
  `ft_expr` int(2) NOT NULL,
  `from_date_expr_2` date NOT NULL,
  `to_date_expr_2` date NOT NULL,
  `organisation_expr_2` varchar(500) CHARACTER SET utf8 NOT NULL,
  `Position_expr_2` varchar(500) CHARACTER SET utf8 NOT NULL,
  `duties_expr_2` varchar(500) CHARACTER SET utf8 NOT NULL,
  `is_ft_expr_2` int(5) NOT NULL,
  `from_date_expr_3` date NOT NULL,
  `to_date_expr_3` date NOT NULL,
  `organisation_expr_3` varchar(500) CHARACTER SET utf8 NOT NULL,
  `Position_expr_3` varchar(500) CHARACTER SET utf8 NOT NULL,
  `duties_expr_3` varchar(500) CHARACTER SET utf8 NOT NULL,
  `is_ft_expr_3` int(5) NOT NULL,
  `pt_expr` int(2) NOT NULL,
  `std_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `experiences`
--

INSERT INTO `experiences` (`id`, `from_date_expr`, `to_date_expr`, `organisation_expr`, `Position_expr`, `duties_expr`, `ft_expr`, `from_date_expr_2`, `to_date_expr_2`, `organisation_expr_2`, `Position_expr_2`, `duties_expr_2`, `is_ft_expr_2`, `from_date_expr_3`, `to_date_expr_3`, `organisation_expr_3`, `Position_expr_3`, `duties_expr_3`, `is_ft_expr_3`, `pt_expr`, `std_id`) VALUES
(1, '2016-02-01', '2016-02-01', 'sdf', 'sdf', 'dsf', 0, '2016-02-22', '2016-02-22', 'sdf', 'sdf', 'sdf', 0, '2016-02-23', '2016-03-01', 'sdf', 'sdf', 'dsf', 0, 0, 12),
(2, '2016-02-25', '2016-03-22', 'يلرس', 'سيب', 'سيب', 0, '2016-02-11', '2016-02-09', 'يسب', 'يبسيب', 'يبس', 0, '0000-00-00', '0000-00-00', '', '', '', -1, 0, 12),
(3, '2016-02-29', '2016-01-31', 'ee', 'e', 'e', 0, '0000-00-00', '0000-00-00', '', '', '', -1, '0000-00-00', '2016-01-22', '', '', '', -1, 0, 13),
(4, '2016-02-08', '2016-02-10', 'n', 'n', 'n', 0, '2016-02-09', '2016-02-09', 'n', 'n', 'n', 0, '2015-10-29', '2016-02-25', 'n', 'n', 'n', 0, 0, 16),
(5, '2016-02-23', '2016-02-15', 'q', 'q', 'q', 0, '2016-02-09', '2016-02-08', 'q', 'qq', 'q', -1, '2016-02-26', '2016-02-15', 'q', 'q', 'q', 0, 0, 17);

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `type_test_1` varchar(500) NOT NULL,
  `date_test_1` date NOT NULL,
  `result_1` varchar(200) NOT NULL,
  `type_test_2` varchar(500) NOT NULL,
  `date_test_2` date NOT NULL,
  `result_2` varchar(200) NOT NULL,
  `type_test_3` varchar(200) NOT NULL,
  `date_test_3` date NOT NULL,
  `result_3` varchar(500) NOT NULL,
  `std_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `type_test_1`, `date_test_1`, `result_1`, `type_test_2`, `date_test_2`, `result_2`, `type_test_3`, `date_test_3`, `result_3`, `std_id`) VALUES
(1, 'tofel', '2016-02-02', 'dddd', 'ielts', '2016-02-02', 'dd', '', '0000-00-00', '', 0),
(2, 'ewr', '0000-00-00', 'gyu', '', '0000-00-00', '', '', '0000-00-00', '', 12),
(3, 'tofel', '2016-02-20', 'asd', 'ads', '0000-00-00', 'asd', 'ads', '0000-00-00', 'asd', 12),
(4, 'tt', '0000-00-00', 't', 'ttt', '0000-00-00', 't', 'ttt', '0000-00-00', 't', 12),
(5, '?????', '2016-02-15', '???', '', '0000-00-00', '', '', '0000-00-00', '', 12),
(6, 'e', '2016-02-01', 'eee', '', '0000-00-00', '', '', '0000-00-00', '', 13),
(7, 'n', '2016-02-16', 'n', 'n', '2016-02-22', 'n', 'n', '2016-03-15', 'n', 16),
(8, 'q', '2016-02-10', 'q', 'q', '2016-02-08', 'q', 'q', '2016-02-16', 'q', 17),
(9, 'q', '2016-02-10', 'q', 'q', '2016-02-08', 'q', 'q', '2016-02-16', 'q', 17);

-- --------------------------------------------------------

--
-- Table structure for table `personal_details`
--

CREATE TABLE IF NOT EXISTS `personal_details` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `choice_1` varchar(500) NOT NULL,
  `choice_2` varchar(500) NOT NULL,
  `choice_3` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  `leave_date` date NOT NULL,
  `is_study_uk` int(1) NOT NULL,
  `title` varchar(5) NOT NULL,
  `bod` date NOT NULL,
  `address` varchar(500) NOT NULL,
  `postcode` varchar(500) NOT NULL,
  `home_tel` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `agancy` varchar(500) NOT NULL,
  `agancy_address` varchar(500) NOT NULL,
  `agancy_postcode` varchar(500) NOT NULL,
  `agancy_Home_tel` varchar(100) NOT NULL,
  `agancy_Mobile` varchar(100) NOT NULL,
  `agancy_email` varchar(200) NOT NULL,
  `outside_eu` varchar(500) NOT NULL,
  `in_eu` varchar(500) NOT NULL,
  `country_birth` varchar(500) NOT NULL,
  `nationality` varchar(500) NOT NULL,
  `permanent_residence` varchar(500) NOT NULL,
  `fees` varchar(500) NOT NULL,
  `std_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `personal_details`
--

INSERT INTO `personal_details` (`id`, `choice_1`, `choice_2`, `choice_3`, `entry_date`, `leave_date`, `is_study_uk`, `title`, `bod`, `address`, `postcode`, `home_tel`, `mobile`, `agancy`, `agancy_address`, `agancy_postcode`, `agancy_Home_tel`, `agancy_Mobile`, `agancy_email`, `outside_eu`, `in_eu`, `country_birth`, `nationality`, `permanent_residence`, `fees`, `std_id`) VALUES
(1, '2016-09-21', 'it', 'it', '2016-02-22', '0000-00-00', 0, '0', '0000-00-00', 'it', 'it', 'it', 'it', 'it', 'it', 'it', 'it', 'it', '', '', '', '', '', '', '', 12),
(2, '2016-02-09', 'qqq', 'qq', '2016-02-23', '0000-00-00', 0, '0', '0000-00-00', 'qq', 'qq', 'qq', 'qqq', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(3, '2016-02-16', 'eee', 'e', '2016-02-23', '0000-00-00', 0, '0', '0000-00-00', 'e', 'e', 'e', '', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(4, '2016-02-01', 'rr', 'rr', '2016-02-16', '0000-00-00', 0, '0', '0000-00-00', 'rrrr', 'rrr', 'r', '', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(5, '2016-02-01', 'w', 'w', '2016-02-16', '0000-00-00', 0, '0', '0000-00-00', 'w', 'w', 'w', '', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(6, '2016-02-09', 'e', 'e', '2016-02-23', '0000-00-00', 0, '0', '0000-00-00', 'e', 'e', 'e', 'e', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(7, '2016-02-09', 'a', 'a', '2016-02-21', '0000-00-00', 0, '0', '0000-00-00', 'cc', 'cc', 'cc', '', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(8, '2016-02-01', 'ww', 'w', '2016-02-22', '0000-00-00', 0, '0', '0000-00-00', 'ww', 'w', 'w', '', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(9, '2016-02-16', 'Engineering', 'Engineering', '2016-02-16', '0000-00-00', 0, 'Mr', '0000-00-00', 'palestine', '05888', '0599266171', '082874111', 'gaza', 'gaza', '02555', '082874411', '0599266171', '', 'fg', 'fg', 'KSA', 'Palestinain', 'KSA', 'KSA', 12),
(10, '2016-03-21', 'Medicne', 'Medicne', '2016-02-24', '0000-00-00', 0, 'Mrs', '0000-00-00', 'Medicne', '00972', '00972', '00972', '00972', '00972', '00972', '00972', '00972', '', '', '', '', '', '', '', 12),
(11, '2016-02-23', 'ttt', 'tt', '2016-02-23', '2016-02-16', 0, 'Mr', '0000-00-00', 't', 't', 't', 't', 't', 't', 't', 't', 't', '', 't', 't', 't', 't', 't', 't', 12),
(12, '2016-02-09', 'qq', 'qq', '2016-02-23', '2016-02-01', 0, 'Mrs', '0000-00-00', 'q', 'q', 'q', 'q', 'q', 'q', '', '', '', '', '', '', '', '', '', '', 12),
(13, '2016-02-09', 'qq', 'qq', '2016-02-23', '2016-02-01', 0, 'Mrs', '0000-00-00', 'q', 'q', 'q', 'q', 'q', 'q', '', '', '', '', '', '', '', '', '', '', 12),
(17, 'das', 'asd', 'ads', '2016-02-01', '2016-02-02', 0, 'Mr', '0000-00-00', 'asd', 'sad', 'asd', 'asd', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(18, '???', '??', '??', '2016-02-23', '2016-02-16', 0, 'Mrs', '0000-00-00', '?', '?', '?', '?', '', '', '', '', '', '', '', '', '', '', '', '', 12),
(19, 'eee', 'ee', 'ee', '2016-02-02', '2016-02-09', 0, 'Mrs', '0000-00-00', 'e', 'e', 'e', 'e', 'ee', '', '', '', '', '', '', '', '', '', '', '', 13),
(20, 'rrr', 'rrr', 'rrr', '2016-02-23', '2016-02-16', 0, 'Mrs', '0000-00-00', 'rrr', 'rrrr', 'rrr', 'rr', '', '', '', '', '', '', '', '', '', '', '', '', 14),
(21, 'yyy', 'yyy', 'y', '2016-02-15', '2016-02-10', 0, 'Mr', '2016-02-16', 'y', 'y', 'y', 'y', 'y', 'y', '', '', '', '', '', '', '', '', '', '', 16),
(22, 'nnnn', 'nnn', 'nn', '2016-02-23', '2016-02-24', 0, 'Mr', '2016-02-02', 'nnnn', 'nn', 'n', 'n', 'n', 'n', 'n', 'n', 'n', '', '', '', '', '', '', '', 16),
(23, 'q', 'q', 'q', '2016-02-23', '2016-02-11', 0, 'Mr', '2016-02-09', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', '', '', '', '', '', '', '', 17);

-- --------------------------------------------------------

--
-- Table structure for table `personal_statment`
--

CREATE TABLE IF NOT EXISTS `personal_statment` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `personal_statment` varchar(2000) NOT NULL,
  `criminal` varchar(500) NOT NULL,
  `std_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `personal_statment`
--

INSERT INTO `personal_statment` (`id`, `personal_statment`, `criminal`, `std_id`) VALUES
(1, 'sdfdsf', 'Undergraduate', 0),
(2, 'dfdfgdg', 'Undergraduate', 12),
(3, 'dgfdg', 'Undergraduate', 12),
(4, 'rrrrrrrrrrr', 'Undergraduate', 12),
(5, 'ttttt', 'Undergraduate', 12),
(6, '???????', '-1', 12),
(7, 'eeeee', 'Undergraduate', 13),
(8, 'nnnn', 'Undergraduate', 16),
(9, 'qqq', 'Undergraduate', 17);

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE IF NOT EXISTS `qualification` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `qualification` varchar(500) CHARACTER SET utf8 NOT NULL,
  `institution` varchar(500) CHARACTER SET utf8 NOT NULL,
  `country` varchar(500) CHARACTER SET utf8 NOT NULL,
  `ft` int(1) NOT NULL,
  `from_date_2` date NOT NULL,
  `to_date_2` date NOT NULL,
  `qualification_2` varchar(500) CHARACTER SET utf8 NOT NULL,
  `institution_2` varchar(500) CHARACTER SET utf8 NOT NULL,
  `country_2` varchar(500) CHARACTER SET utf8 NOT NULL,
  `is_ft_2` int(5) NOT NULL,
  `from_date_3` date NOT NULL,
  `to_date_3` date NOT NULL,
  `qualification_3` varchar(500) CHARACTER SET utf8 NOT NULL,
  `institution_3` varchar(500) CHARACTER SET utf8 NOT NULL,
  `country_3` varchar(500) CHARACTER SET utf8 NOT NULL,
  `is_ft_3` int(5) NOT NULL,
  `std_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`id`, `from_date`, `to_date`, `qualification`, `institution`, `country`, `ft`, `from_date_2`, `to_date_2`, `qualification_2`, `institution_2`, `country_2`, `is_ft_2`, `from_date_3`, `to_date_3`, `qualification_3`, `institution_3`, `country_3`, `is_ft_3`, `std_id`) VALUES
(1, '0000-00-00', '0000-00-00', 'fff', 'fff', 'fff', 12, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(2, '2016-02-01', '2016-02-01', 'sss', 'sss', 'sss', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(3, '0000-00-00', '0000-00-00', 'hhhh', 'hhhh', 'hhhh', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(4, '0000-00-00', '2016-02-01', 'vv', 'vv', 'vv', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 0),
(5, '2016-02-01', '2016-02-01', 'nnnn', 'nnn', 'nnn', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 12),
(6, '2016-02-01', '2016-02-01', 'oo', 'oo', 'ooo', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 12),
(7, '2016-02-01', '2016-02-01', 'oo', 'oo', 'ooo', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 12),
(8, '2016-02-01', '2016-02-01', 'tt', 'tt', 'tt', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 12),
(9, '2016-02-01', '2016-02-01', 'yy', 'yyy', 'yyy', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 12),
(10, '2016-02-01', '2016-02-01', 'ff', 'ff', 'ff', 1, '0000-00-00', '0000-00-00', '', '', '', 0, '0000-00-00', '0000-00-00', '', '', '', 0, 12),
(11, '2016-02-01', '2016-02-01', 'dsfsdf', 'sdf', 'sdf', 0, '2016-02-01', '2016-02-01', 'sdfsdf', 'sdf', 'sdf', -1, '2016-02-01', '2016-02-01', 'sdf', 'dsf', 'sdf', -1, 12),
(12, '2016-02-01', '2016-02-01', 'Islamic university', 'Islamic university', 'Islamic university', 0, '2016-02-01', '2016-02-01', 'Islamic university', 'Islamic university', 'Islamic university', 0, '2016-02-01', '2016-02-01', 'Islamic university', 'Islamic university', 'Islamic university', -1, 12),
(13, '2016-02-02', '2016-02-02', 't', 't', 't', 0, '2016-02-02', '2016-02-02', 't', 't', 't', 0, '2016-02-02', '2016-02-02', 't', 't', 't', -1, 12),
(14, '2016-02-02', '2016-02-24', 'sdf', 'sdf', 'sdf', -1, '0000-00-00', '0000-00-00', '', '', '', -1, '0000-00-00', '0000-00-00', '', '', '', -1, 12),
(15, '2016-02-22', '2016-02-02', 'ءبءؤ', 'ؤرؤء', 'ءرءؤر', 0, '0000-00-00', '0000-00-00', '', '', '', -1, '0000-00-00', '0000-00-00', '', '', '', -1, 12),
(16, '2016-02-03', '2016-02-02', 'e', 'e', 'e', 0, '0000-00-00', '0000-00-00', '', '', '', -1, '0000-00-00', '0000-00-00', '', '', '', -1, 13),
(17, '2016-02-08', '2016-02-15', 'rrr', 'rrr', 'rrrr', 0, '0000-00-00', '0000-00-00', '', '', '', -1, '0000-00-00', '0000-00-00', '', '', '', -1, 14),
(18, '2016-02-23', '2016-02-22', 'vvv', 'vvv', 'vv', 0, '2016-02-23', '2016-02-16', 'vv', 'vv', 'vv', 0, '2016-02-16', '2016-02-24', 'vv', 'v', 'v', 0, 14),
(19, '2016-02-23', '2016-02-16', 'n', 'n', 'nnn', 0, '2016-02-16', '2016-02-16', 'n', 'n', 'n', 0, '2016-02-23', '2016-02-15', 'n', 'n', 'n', 0, 16),
(20, '2016-02-16', '2016-02-03', 'q', 'q', 'q', 0, '2016-02-23', '2016-02-16', 'qq', 'q', 'q', 0, '2016-02-09', '2016-02-08', 'q', 'q', 'q', 0, 17);

-- --------------------------------------------------------

--
-- Table structure for table `references`
--

CREATE TABLE IF NOT EXISTS `references` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `referee` varchar(500) NOT NULL,
  `Position` varchar(500) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Tel` varchar(500) NOT NULL,
  `Fax` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `requir` varchar(500) NOT NULL,
  `Information` varchar(500) NOT NULL,
  `std_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `references`
--

INSERT INTO `references` (`id`, `referee`, `Position`, `Address`, `Tel`, `Fax`, `email`, `requir`, `Information`, `std_id`) VALUES
(1, 'ertet', 'ertert', 'ertert', 'erter', 'ete', '', 'etert', 'erter', 12),
(2, 'rr', 'rr', 'r', 'r', 'r', 'r', 'r', 'r', 12),
(3, 'eee', 'ee', 'ee', 'e', 'ee', 'ee', 'e', 'e', 12),
(4, 'tt', 'ttt', 'ttt', 'tt', 'tt', 'tt', 'tt', 'ttt', 12),
(5, '???', '??', '???', '??', '', '?????', '???', '??', 12),
(6, 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 13),
(7, 'n', 'n', 'nn', 'n', 'n', 'nnn@dfdf.dfdf', 'n', 'n', 16),
(8, 'q', 'q', 'q', 'q', 'q', 'qqq@df.qqqqdf', 'q', 'q', 17);

-- --------------------------------------------------------

--
-- Table structure for table `rel_role_action`
--

CREATE TABLE IF NOT EXISTS `rel_role_action` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(9) unsigned NOT NULL,
  `action_id` int(9) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `header_setting` tinyint(1) NOT NULL DEFAULT '0',
  `address` text NOT NULL,
  `contact` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `date_format` varchar(255) NOT NULL,
  `timezone` varchar(255) NOT NULL,
  `smtp_host` varchar(255) NOT NULL,
  `smtp_user` varchar(255) NOT NULL,
  `smtp_pass` varchar(255) NOT NULL,
  `smtp_port` varchar(255) NOT NULL,
  `mark_out_time` time NOT NULL,
  `invoice_no` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `image`, `header_setting`, `address`, `contact`, `email`, `employee_id`, `date_format`, `timezone`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `mark_out_time`, `invoice_no`) VALUES
(1, 'Advocate', '', 0, '', '', 'advocate@advocate.com', 0, '', '', '', '', '', '', '00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `case_id` int(10) unsigned NOT NULL,
  `priority` int(10) unsigned NOT NULL,
  `due_date` date NOT NULL,
  `progress` varchar(255) NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_assigned`
--

CREATE TABLE IF NOT EXISTS `task_assigned` (
  `user_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `family_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(40) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `Nationality` varchar(200) NOT NULL,
  `Country` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `course` varchar(200) NOT NULL,
  `level_study` varchar(200) NOT NULL,
  `start_date` date NOT NULL,
  `contact` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `user_role` int(10) NOT NULL,
  `token` varchar(255) NOT NULL,
  `client_case_alert` int(10) NOT NULL DEFAULT '1',
  `department_id` int(10) unsigned NOT NULL,
  `designation_id` int(10) unsigned NOT NULL,
  `joining_date` date NOT NULL,
  `joining_salary` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `family_name`, `first_name`, `employee_id`, `name`, `image`, `username`, `password`, `gender`, `dob`, `email`, `Nationality`, `Country`, `phone`, `course`, `level_study`, `start_date`, `contact`, `address`, `user_role`, `token`, `client_case_alert`, `department_id`, `designation_id`, `joining_date`, `joining_salary`, `status`) VALUES
(1, '', '', 0, 'ahmed', '', 'ahmed', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', '0000-00-00', 'a7.y.q@hotmail.com', '', '', '', '', '', '0000-00-00', '', '', 1, '', 1, 0, 0, '0000-00-00', '', 1),
(2, '', '', 11, 'moh', '', 'moh', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', '0000-00-00', 'a7.y.q@hotmail.com', '', '', '', '', '', '0000-00-00', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(3, '', '', 12, 'احمد يونس محمد ابو القمصان', '11787316_483852848448308_1639905478_n.jpg', 'admin', 'b2ee60370ad57d9bc3877e9024c507ab99303a64', 'Male', '2016-02-11', 'ayman.ablan@hotmail.com', '', '', '', '', '', '0000-00-00', '2222', 'dddd', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(4, 'qqqqqq', 'qqqq', 0, '', '', 'qqqq', '33a9e269dd782e92489a8e547b7ed582e0e1d42b', 'on', '0000-00-00', 'qqq@df.df', 'qqq', 'qq', 'qqq', 'qqq', 'Undergraduate', '0000-00-00', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(5, 'fffff', 'fffff', 0, '', '', 'fff', 'c81019207890deb5cba8cda1de0dd6b1c229eeff', 'on', '0000-00-00', 'fff@sd.sd', 'fff', 'fff', '2525', 'ffff', 'Undergraduate', '0000-00-00', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(6, 'wael', 'Wael', 0, '', '', 'wael', '7c4a8d09ca3762af61e59520943dc26494f8941b', '-1', '0000-00-00', 'wael@ads.sd', 'wael', 'Wael', '2222', 'wael', '-1', '0000-00-00', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(7, 'ss', 'ss', 0, '', '', 'ss', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'male', '0000-00-00', 'ss@sd.sd', 'ss', 's', 'ss', 'ss', 'Undergraduate', '0000-00-00', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(8, 'vv', 'vv', 0, '', '', 'ddd', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'male', '0000-00-00', 'vv@wwe.er', 'vv', 'vv', '22', 'ss', 'Undergraduate', '0000-00-00', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(9, 'vv', 'vv', 0, '', '', 'wws', 'b2ee60370ad57d9bc3877e9024c507ab99303a64', '-1', '0000-00-00', 'vsdv@wwe.er', 'vv', 'vv', '22', 'ss', '-1', '0000-00-00', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(10, 'mohammed', 'qumsan', 0, '', '', 'eee', 'b2ee60370ad57d9bc3877e9024c507ab99303a64', 'male', '0000-00-00', 'asas@sdsd.sd', 'palestine', 'palestine', '287411', 'eeee', 'Undergraduate', '0000-00-00', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(11, 'ttt', 'ttt', 0, '', '', 'erer', 'b2ee60370ad57d9bc3877e9024c507ab99303a64', 'male', '2001-03-01', 'ttt@ererer.er', 'tt', 'ttt', 'erer', 'erer', 'Undergraduate', '2016-02-18', '', '', 0, '', 1, 0, 0, '0000-00-00', '', 1),
(12, 'ahmed', 'mohammed', 0, 'ahmed qumsan', '', 'ah', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'male', '1989-05-04', 'tdtt@ererer.er', 'tt', 'ttt', 'erer', 'erer', 'Undergraduate', '2016-02-18', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(13, 'qumsan', 'mohammed', 0, '', '', 'mohd', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'female', '2016-02-23', 'ahmss.a@hotmail.com', 'palestine', 'palestine', '14', 'IT', 'Undergraduate', '2016-02-24', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(14, 'aaaaa', 'aaaaaa', 0, '', '', 'aaa', '7c4a8d09ca3762af61e59520943dc26494f8941b', '-1', '2016-02-24', 'aaa@sdsd.sds', 'aaaa', 'aaaaa', '082874411', 'IT', '-1', '2016-02-15', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(15, '0', 'badr', 0, '', '', 'aaaa', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'male', '2016-02-16', 'badr@dfd.fd', 'badr', 'badr', 'badr', 'badr', 'Undergraduate', '2016-02-10', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(16, '', 'mohammmed', 0, 'mohammmed', '', 'as', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'male', '2016-02-09', 'mohammmed@df.dfd', 'mohammmed', 'mohammmed', 'mohammmed', 'mohammmed', 'Undergraduate', '2016-02-02', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1),
(17, '', 'qqq', 0, 'qqqq', '', 'qq', '7c4a8d09ca3762af61e59520943dc26494f8941b', '-1', '2016-03-22', 'qqq@df.qqqdf', 'qqq', 'qqq', 'qq', 'q', 'Undergraduate', '2016-02-01', '', '', 2, '', 1, 0, 0, '0000-00-00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `name`, `description`) VALUES
(1, 'Admin', 'Admin Have All Rights'),
(2, 'Clients', 'Clients Have Default Permission');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
