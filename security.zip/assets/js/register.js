function register_new_std()
{
		   /*var choice_1= $('#choice_1').val();
		   var choice_2= $('#choice_2').val();
		   var choice_3= $('#choice_3').val();
		   var entry_date= $('#entry_date').val();
		   var leave_date= $('#leave_date').val();
		   var dob= $('#bod').val();
		   var address= $('#address').val();
		   var postcode= $('#postcode').val();
		   var home_tel= $('#home_tel').val();


	 if((choice_1 == "" || choice_1 == null))
	   	{
			
            alert("Please enter Choice 1");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((choice_2 == "" || choice_2 == null))
	   	{
			
            alert("Please enter Choice 2");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((choice_3 == "" || choice_3 == null))
	   	{
			
            alert("Please enter Choice 3");
		return false;
		}
                 else
                { 
            null;
                 }
		 if((entry_date == "" || entry_date == null))
	   	{
			
            alert("Please enter Entry date");
		return false;
		}
                 else
                { 
            null;
                 }
	 if((leave_date == "" || leave_date == null))
	   	{
			
            alert("Please enter Leave date");
		return false;
		}
                 else
                { 
            null;
                 }
		if((dob == "" || dob == null))
	   	{
			
            alert("Please enter Birth Of Date");
		return false;
		}
                 else
                { 
            null;
                 }
		if((address == "" || address == null))
	   	{
			
            alert("Please enter Address");
		return false;
		}
                 else
                { 
            null;
                 }
		if((postcode == "" || postcode == null))
	   	{
			
            alert("Please enter Post Code");
		return false;
		}
                 else
                { 
            null;
                 }
		 if((home_tel == "" || home_tel == null))
	   	{
			
            alert("Please enter Home Tel");
		return false;
		}
                 else
                { 
            null;
                 }*/
				 		 
				
	$.ajax({
			url: "regiser_student/register_new_std",
			type: "POST",
			data:  $("#register").serialize(),
			error: function(xhr, status, error) {
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
					 
					/* $("#from_date").focus();
				 $("#collapse_1").hide("fast");
				 $("#collapse_2").show("fast");
				 alert("Has been successfully added");
				$("#personal_details_form").find("input,button,textarea,select").attr("disabled", "disabled");*/
			
			
			
							
							
							
							$.ajax({
			url: "regiser_student/sendmail",
			type: "POST",
			data:  $("#register").serialize(),
			error: function(xhr, status, error) {
  				//var err = eval("(" + xhr.responseText + ")");
  				//alert(xhr.responseText);
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#referenses_form');
				Metronic.scrollTo( $('.alert-danger', form), -200);
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				/*alert("Has been successfully added");
				$("#maxlength_textarea").focus();
				$("#referenses_form").find("input,button,textarea,select").attr("disabled", "disabled");
				// $("#collapse_1").show("fast");
				 $("#collapse_4").hide("fast");
				
				
				*/
			}
		});//END $.ajax
			
			
			
			
			}
			
		});//END $.ajax
}