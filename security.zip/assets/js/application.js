function add_personal_details()
{
		   var choice_1= $('#choice_1').val();
		   var choice_2= $('#choice_2').val();
		   var choice_3= $('#choice_3').val();
		   var entry_date= $('#entry_date').val();
		   var leave_date= $('#leave_date').val();
		   var email= $('#emails').val();
		   var dob= $('#bod').val();
		   var address= $('#address').val();
		   var postcode= $('#postcode').val();
		   var home_tel= $('#home_tel').val();


	 if((choice_1 == "" || choice_1 == null))
	   	{
			
            alert("Please enter Choice 1");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((choice_2 == "" || choice_2 == null))
	   	{
			
            alert("Please enter Choice 2");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((choice_3 == "" || choice_3 == null))
	   	{
			
            alert("Please enter Choice 3");
		return false;
		}
                 else
                { 
            null;
                 }
		 if((entry_date == "" || entry_date == null))
	   	{
			
            alert("Please enter Entry date");
		return false;
		}
                 else
                { 
            null;
                 }
	 if((leave_date == "" || leave_date == null))
	   	{
			
            alert("Please enter Leave date");
		return false;
		}
                 else
                { 
            null;
                 }
	 if((email == "" || email == null))
	   	{
			
            alert("Please enter Email");
		return false;
		}
                 else
                { 
            null;
                 }
				 
				 
		if((dob == "" || dob == null))
	   	{
			
            alert("Please enter Birth Of Date");
		return false;
		}
                 else
                { 
            null;
                 }
		if((address == "" || address == null))
	   	{
			
            alert("Please enter Address");
		return false;
		}
                 else
                { 
            null;
                 }
		if((postcode == "" || postcode == null))
	   	{
			
            alert("Please enter Post Code");
		return false;
		}
                 else
                { 
            null;
                 }
		 if((home_tel == "" || home_tel == null))
	   	{
			
            alert("Please enter Home Tel");
		return false;
		}
                 else
                { 
            null;
                 }
				 		 
				
	$.ajax({
			url: "application/add_personal_details",
			type: "POST",
			data:  $("#personal_details_form").serialize(),
			error: function(xhr, status, error) {
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
					 
					 $("#from_date").focus();
				 $("#collapse_1").hide("fast");
				 $("#collapse_2").show("fast");
				 alert("Has been successfully added");
				$("#personal_details_form").find("input,button,textarea,select").attr("disabled", "disabled");
				
				
							
		/*	$.ajax({
			url: "application/sendmail",
			type: "POST",
			data:  $("#referenses_form").serialize(),
			error: function(xhr, status, error) {
  				//var err = eval("(" + xhr.responseText + ")");
  				//alert(xhr.responseText);
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#referenses_form');
				Metronic.scrollTo( $('.alert-danger', form), -200);
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				alert("Has been successfully added");
				$("#maxlength_textarea").focus();
				$("#referenses_form").find("input,button,textarea,select").attr("disabled", "disabled");
				// $("#collapse_1").show("fast");
				 $("#collapse_4").hide("fast");
				
				
				
			}
		});//END $.ajax	*/
			

			}
			
		});//END $.ajax
}

function add_qualification()
{
	   var from_date= $('#from_date').val();
		   var to_date= $('#to_date').val();
		   var qualification= $('#qualification').val();
		   var institution= $('#institution').val();
		   var country= $('#country').val();
		   var ft= $('#ft').val();



	 if((from_date == "" || from_date == null))
	   	{
			
            alert("Please enter From Date");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((to_date == "" || to_date == null))
	   	{
			
            alert("Please enter To Date");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((qualification == "" || qualification == null))
	   	{
			
            alert("Please Enter Qualification");
		return false;
		}
                 else
                { 
            null;
                 }
		 if((institution == "" || institution == null))
	   	{
			
            alert("Please Enter Institution");
		return false;
		}
                 else
                { 
            null;
                 }
	 if((country == "" || country == null))
	   	{
			
            alert("Please Enter Country");
		return false;
		}
                 else
                { 
            null;
                 }

		if((ft == "-1" || ft == null))
	   	{
			
            alert("Please Choose Full Time Or Part Time");
		return false;
		}
                 else
                { 
            null;
                 }
	
	
	$.ajax({
			url: "application/add_qualification",
			type: "POST",
			data:  $("#qua_form").serialize(),
			error: function(xhr, status, error) {
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#user_form');
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				alert("Has been successfully added");
				$("#from_date_expr").focus();
				$("#qualifiaction_table").find("input,button,textarea,select").attr("disabled", "disabled");
				
				
				
			}
		});//END $.ajax
}

function add_work_experince()
{
	   var from_date_expr= $('#from_date_expr').val();
		   var to_date_expr= $('#to_date_expr').val();
		   var organisation_expr= $('#organisation_expr').val();
		   var Position_expr= $('#Position_expr').val();
		   var duties_expr= $('#duties_expr').val();
		   var is_ft_3= $('#is_ft_3').val();



	 if((from_date_expr == "" || from_date_expr == null))
	   	{
			
            alert("Please enter From date");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((to_date_expr == "" || to_date_expr == null))
	   	{
			
            alert("Please enter To date");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((organisation_expr == "" || organisation_expr == null))
	   	{
			
            alert("Please enter organisation name");
		return false;
		}
                 else
                { 
            null;
                 }
		 if((Position_expr == "" || Position_expr == null))
	   	{
			
            alert("Please enter Position ");
		return false;
		}
                 else
                { 
            null;
                 }
	 if((duties_expr == "" || duties_expr == null))
	   	{
			
            alert("Please enter duties");
		return false;
		}
                 else
                { 
            null;
                 }

		if((is_ft_3 == "-1" || is_ft_3 == null))
	   	{
			
            alert("Please Choose Full Time Or part Time");
		return false;
		}
                 else
                { 
            null;
                 }
	
	$.ajax({
			url: "application/add_experices",
			type: "POST",
			data:  $("#work_experince_form").serialize(),
			error: function(xhr, status, error) {
  				//var err = eval("(" + xhr.responseText + ")");
  				//alert(xhr.responseText);
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#work_experince_form');
				Metronic.scrollTo( $('.alert-danger', form), -200);
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				alert("Has been successfully added");
				$("#TOEFL_1").focus();
				$("#work_experince_form").find("input,button,textarea,select").attr("disabled", "disabled");
				
				
				
				
			}
		});//END $.ajax
}


function add_language()
{
	 	   var TOEFL_1= $('#TOEFL_1').val();
		   var date_test_1= $('#date_test_1').val();
		   var result_1= $('#result_1').val();




	 if((TOEFL_1 == "" || TOEFL_1 == null))
	   	{
			
            alert("Please enter Type of Test");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((date_test_1 == "" || date_test_1 == null))
	   	{
			
            alert("Please enter  	Date of Test ");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((result_1 == "" || result_1 == null))
	   	{
			
            alert("Please enter Result");
		return false;
		}
                 else
                { 
            null;
                 }
		
	
	$.ajax({
			url: "application/add_language",
			type: "POST",
			data:  $("#language_form").serialize(),
			error: function(xhr, status, error) {
  				//var err = eval("(" + xhr.responseText + ")");
  				//alert(xhr.responseText);
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#language_form');
				Metronic.scrollTo( $('.alert-danger', form), -200);
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				alert("Has been successfully added");
				$("#maxlength_textarea").focus();
				$("#language_form").find("input,button,textarea,select").attr("disabled", "disabled");
				 $("#collapse_2").hide("fast");
				 $("#collapse_3").show("fast");
				
				
				
			}
		});//END $.ajax
}


function add_personal_statment()
{
  		   var maxlength_textarea= $('#maxlength_textarea').val();
		   var criminal= $('#criminal').val();




	 if((maxlength_textarea == "" || maxlength_textarea == null))
	   	{
			
            alert("Please enter reasons why you want to study at Leeds Beckett University");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((criminal == "" || criminal == null))
	   	{
			
            alert("Please Choose criminal ");
		return false;
		}
                 else
                { 
            null;
                 }	
	$.ajax({
			url: "application/add_personal_statment",
			type: "POST",
			data:  $("#personal_statment_form").serialize(),
			error: function(xhr, status, error) {
  				//var err = eval("(" + xhr.responseText + ")");
  				//alert(xhr.responseText);
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#personal_statment_form');
				//Metronic.scrollTo( $('.alert-danger', form), -200);
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				alert("Has been successfully added");
				$("#maxlength_textarea").focus();
				$("#personal_statment_form").find("input,button,textarea,select").attr("disabled", "disabled");
				 $("#collapse_3").hide("fast");
				 $("#collapse_4").show("fast");
				
				
				
			}
		});//END $.ajax
}

function add_refrences()
{
		   var referee= $('#referee').val();
		   var Position= $('#Position').val();
		     var Address= $('#Address').val();
		   var Tel= $('#Tel').val();
		     var email= $('#email').val();
		   var requir= $('#requir').val();




	 if((referee == "" || referee == null))
	   	{
			
            alert("Please enter references");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((Position == "" || Position == null))
	   	{
			
            alert("Please Choose Position ");
		return false;
		}
                 else
                { 
            null;
                 }	
				 
				  if((Address == "" || Address == null))
	   	{
			
            alert("Please enter Address");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((Tel == "" || Tel == null))
	   	{
			
            alert("Please Choose Tel ");
		return false;
		}
                 else
                { 
            null;
                 }	
				 
				  if((email == "" || email == null))
	   	{
			
            alert("Please enter email");
		return false;
		}
                 else
                { 
            null;
                 }
				 
		if((requir == "" || requir == null))
	   	{
			
            alert("Please Choose requir ");
		return false;
		}
                 else
                { 
            null;
                 }	
	$.ajax({
			url: "application/add_refrences",
			type: "POST",
			data:  $("#referenses_form").serialize(),
			error: function(xhr, status, error) {
  				//var err = eval("(" + xhr.responseText + ")");
  				//alert(xhr.responseText);
				$('#spnMsg').text('حدث خطأ أثناء عملية حفظ البانات ... الرجاء المحاولة مرة أخرى');
				var form = $('#referenses_form');
				Metronic.scrollTo( $('.alert-danger', form), -200);
			},
			beforeSend: function(){},
			complete: function(){},
			success:function(data) {
				alert("Has been successfully added");
				$("#maxlength_textarea").focus();
				$("#referenses_form").find("input,button,textarea,select").attr("disabled", "disabled");
				// $("#collapse_1").show("fast");
				 $("#collapse_4").hide("fast");
				
				
		
								
				
			}
		});//END $.ajax
}
